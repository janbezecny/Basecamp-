# Prompt: AOV 2027 – CZ e-shop (2 nejlepší modely + forecast 2027)

> Konsolidovaná verze předchozí vícekrokové konverzace. Vložte celý blok níže do nového chatu
> a přiložte uvedené soubory. Cíle růstu a názvy souborů upravte, pokud se změní.

---

```text
ROLE
Jsi senior analytik pro forecasting e-commerce KPI. Pracuješ samostatně, výpočty děláš v Pythonu
(pandas, statsmodels) a výstup dodáš jako jeden Excel se živými vzorci + stručné shrnutí v chatu.
Odpovídej česky, čísla v Kč s mezerou jako oddělovačem tisíců.

CÍL
Najdi 2 nejlepší použitelné modely průměrné hodnoty objednávky (AOV) pro CZ e-shop a dej jejich
forecast na rok 2027 (měsíčně I–XII/2027 + roční hodnota + pásmo). Jeden model na GA/BI bázi,
jeden na sales/ERP bázi. Výběr musí být podložen backtestem, ne intuicí.
Modeluješ pouze CZ eshop. Jiné existující forecasty/plány nepoužívej a nesrovnávej se s nimi.

VSTUPNÍ DATA (přiložena)
1) BI exporty „AOV allocated“ – měsíčně per kanál, CZ eshop, I/2025–X/2026, ~24 kanálů.
   Filtr exportu: E-shop = CZ eshop, DivisionSubType = eshop.
   Soubory (22 měsíců):
   - 2025: Leden_AOV_2025_2.xlsx, Únor_AOV_2025.xlsx, Březen_AOV_2025.xlsx, Duben_AOV_2025.xlsx,
     Květen_AOV_2025.xlsx, Červen_AOV_2025.xlsx, Červenec_AOV_2025.xlsx, Srpen_AOV_2025.xlsx,
     Září_AOV_2025.xlsx, Říjen_AOV_2025.xlsx, Listopad_AOV_2025.xlsx, Prosinec_AOV_2025.xlsx
     (každý soubor = 1 měsíc, list Sheet1)
   - 2026 I–V: Leden_AOV_2026.xlsx, Únor_AOV_2026.xlsx, Březen_AOV_2026.xlsx,
     Duben_AOV_2026.xlsx, Květen_AOV_2026.xlsx (list Sheet1)
   - 2026 VI–X: AOV_data_2025-2026.xlsx – jeden soubor, měsíc = list:
     Sheet1 (4) = VI/2026, Sheet1 (3) = VII, Sheet1 (2) = VIII, Sheet1 (1) = IX, Sheet1 = X/2026
   Sloupce: Channel, Sales allocated, Orders allocated, AOV allocated, GM1 allocated, Ads costs,
   PNO allocated, Orders measured (+ estimated varianty – nepoužívat).
   AOV = Sales allocated / Orders allocated (ověř na všech řádcích).
   Báze obsahuje produkty + služby (poštovné, balné).
2) „Vývoj AOV 2023-2026 CZ SK HU.xlsx“ – měsíční produktové AOV (sales/ERP, BEZ služeb),
   I/2023–X/2026. Použij jen list/řadu CZ.
3) GA data CZ e-shop po kanálech a dnech (denní granularita, 1. 1. 2025 – 31. 10. 2026):
   - CZ_1_6_2025_GA.xlsx   (1. 1. – 30. 6. 2025)
   - CZ_7-12_2025_GA.xlsx  (1. 7. – 31. 12. 2025)
   - CZ_1_10_2026_GA.xlsx  (1. 1. – 31. 10. 2026)
   Struktura: list Sheet1, řádek 1 = popis filtrů (E-shop = CZ eshop, DivisionSubType = eshop,
   Cookie measurement type = standard, Web sessions není prázdné), řádek 2 prázdný,
   hlavička na řádku 3 (načítat header=2). 1 řádek = kanál × den, řádky nejsou seřazené.
   Sloupce: E-shops hierarchy – E-shop, E-shops hierarchy – E-shop (detail), Channel, Date,
   Sessions est, GA conversion rate, CR invoice est, Orders est, Sales est, AOV est, GM1 est,
   GP est incl services, GP est products, Ads costs, Ads clicks, PNO est,
   MP1 est incl services, MP1 est products.
   24 kanálů (Channel): Google organic, Direct, Google ads brand, Google brand organic,
   Google ads sea, Google ads pmax, Newsletter, Google ads pla, SMS, Seznam sklik brand, Other,
   Heureka, Referral, Organic other, Seznam organic, Seznam brand organic, Facebook,
   Seznam sklik sea, Zbozi, Affil, Srovname, Google ads other, Seznam sklik other,
   Seznam sklik display.
   Pozor: GA používá metriky „est“ (odhad), BI exporty „allocated“ → AOV se v jednotlivých
   měsících liší (např. I/2025 GA 905 vs. BI 938 Kč). Porovnávej růsty a podíly, ne koruny;
   rozdíl GA vs. BI po měsících vyčísli. AOV vždy počítej jako Σ Sales est / Σ Orders est
   (nikdy neprůměruj sloupec AOV est).
   Použití: (a) přesné určení data zlomu navýšení PPC (Ads costs po dnech/týdnech),
   (b) denní/týdenní AOV a mix kanálů před a po zlomu, (c) proxy služeb:
   GP est incl services − GP est products = hrubý zisk ze služeb (Kč/objednávku, měsíčně)
   – použij k odhadu vlivu služeb na AOV a k ověření rozdílu BI vs. ERP.
   Kanály namapuj na stejných 7 skupin jako BI (Brand = Google ads brand + Google brand
   organic + Seznam sklik brand + Seznam brand organic; Paid search non-brand = Google ads sea
   + Seznam sklik sea + Google ads other + Seznam sklik other/display; Shopping/Pmax/srovnávače
   = Google ads pmax + Google ads pla + Heureka + Zbozi + Srovname; CRM = Newsletter + SMS;
   Organic non-brand = Google organic + Seznam organic + Organic other; Direct;
   Social/Affil/Referral/Other = Facebook + Affil + Referral + Other) a mapování ukaž.

DŮLEŽITÉ VLASTNOSTI DAT (ošetři)
- Říjen 2026 v BI = jen 1.–30. 10. → pro AOV bez vlivu, objemy jsou neúplné.
- Listopad–prosinec 2026 nejsou skutečnost → nejdřív je dopočítej (viz krok 4).
- BI vs. ERP: báze se liší definicí objednávek (BI alokované, ERP realizované) i obsahem
  (BI včetně služeb). Porovnávej růsty, ne koruny. Spočti měsíční koeficient k = AOV BI / AOV ERP
  a jeho stabilitu; služby z těchto dat přímo izolovat nejde – uveď to jako omezení.
- Roční AOV počítej vážené objednávkami; jako váhy použij Orders allocated z BI
  (pro 2023–2024 ERP řady prostý průměr).
- Kanály agreguj do 7 skupin: Brand (paid+organic sloučeně – atribuce mezi nimi skáče),
  Organic non-brand, Direct, Paid search non-brand, Shopping/Pmax/srovnávače,
  CRM (Newsletter+SMS), Social/Affil/Referral/Other.
- Ověř podezřelé měsíce (např. leden–únor 2026 slabé, červenec 2026 anomálně silný,
  propad IX–X 2026).

CÍL RŮSTU TRŽEB 2027 (YoY, pro výpočet implikací)
Měsíc:     1    2    3    4    5    6    7    8    9   10   11   12  CELKEM
CZ eshop:  5%   5%   5%  10%  10%   5%   8%   8%   5%   5%   5%   5%   6%
SK eshop: 15%  15%  15%  15%  15%  15%  15%  15%  15%  15%  15%  15%  15%
(SK jen pro kontext – modeluje se pouze CZ.)

POSTUP
1) Načti a sjednoť data, zkontroluj AOV = Sales/Orders, spočti sezónní indexy, YoY, LTM,
   klouzavý 12M průměr. Pro BI rozlož meziroční změnu AOV na mixový a vnitrokanálový efekt.
2) Kandidátní modely:
   GA/BI báze:
   - A0 sezónní naivní (= stejný měsíc loni)
   - A1 sezónní naivní × YoY posledních známých měsíců
   - A  top-down: sezónní profil × trend z log-lineární regrese s měsíčními dummy
   - B1 bottom-up mix: Σ (podíl objednávek skupiny × AOV skupiny), mix LTM
   - B3 bottom-up mix s mixem posledních 4 měsíců
   - ensemble A1+B1
   ERP báze (časová řada 2023–2026):
   - TS1 Holt-Winters / ETS(A,N,A) bez trendu, α=γ=0,1 (+ varianta s optimalizovanými parametry)
   - TS2 SARIMA(0,1,1)(0,1,1)12 „airline“ (+ auto-ARIMA dle AIC)
   - TS3 sezónní naivní (drift 0 a drift = YoY 12M)
   - Holt-Winters s tlumeným trendem (aditivní i multiplikativní)
   - log-lineární regrese s trendem a sezónou
   - ensemble TS1+TS3
3) BACKTEST (rolling origin, jen ex ante informace – žádná znalost budoucího mixu ani trendu):
   - Hlavní řez: data do 31. 3. 2026 → predikce IV–XII/2026, vyhodnoť na IV–X/2026.
   - Kontrolní řezy: do X/2025 (h=12), do IV/2026, do VI/2026, do VIII/2026 (→ IX–X).
   - Metriky: MAPE, bias (+ = přestřelení), chyba průměrného AOV za testované období.
   - Ex post varianty (např. B2 se skutečným mixem) uváděj jen jako diagnostiku, ne pro výběr.
   Pravidla výběru: nejnižší MAPE na hlavním řezu, |bias| < 2 %, stabilita přes řezy;
   modely, které extrapolují pokles 2023–25 (trend), preferuj jen jako dolní okraj.
4) Dopočet XI–XII/2026 vybranými modely (tři varianty podle toho, kolik z propadu IX–X 2026
   přeteče: w = 0 / 0,5 / 1; spočti autokorelaci odchylek a w zdůvodni). Z toho 2026E.
5) VÁHA REŽIMU VIII–X/2026 (navýšení PPC):
   Od léta 2026 se výrazně navýšily investice do PPC. Orientačně z GA: Ads costs
   VI/2026 1,25 mil. → VII 2,11 → VIII 2,64 → IX 2,61 → X 2,27 mil. Kč; PNO 7,6 % → 9,6 →
   11,2 → 13,6 → 11,6 %; AOV (GA est) VII 1 069, VIII 1 079, IX 1 006, X 987 Kč.
   Týdenní data naznačují náběh od poloviny VII a plný režim od týdne končícího 9. 8. 2026
   (PNO > 12 %), v druhé polovině X mírné snížení – ověř.
   Anomálie: IV/2026 má Ads costs jen 0,28 mil. Kč (PNO 2,2 %) – zkontroluj, zda jde o
   výpadek dat nákladů, a případně vyřaď z analýzy PNO.
   a) Z denních GA dat urči datum zlomu (změna nákladů PPC / podílu paid search a Shopping
      na objednávkách) a porovnej období před a po zlomu: AOV celkem, AOV po skupinách,
      podíl objednávek po skupinách, PNO. Rozlož změnu AOV na mixový a vnitrokanálový efekt.
   b) Zaveď parametr v = váha vývoje VIII–X/2026 (žlutá buňka, 0–1):
      - v = 0 → forecast 2027 jen z dlouhodobé historie (vybrané modely bez úpravy),
      - v = 1 → režim VIII–X/2026 trvá celý rok 2027 (mix kanálů a vnitrokanálová AOV
        z období po zlomu, YoY dynamika VIII–X aplikovaná na sezónní profil),
      - mezi tím lineární kombinace: AOV_2027_m = (1 − v) · AOV_base_m + v · AOV_PPC_m.
      Spočti varianty v = 0 / 0,25 / 0,5 / 0,75 / 1 pro oba vybrané modely.
   c) Doporuč v a zdůvodni (pokračuje navýšený PPC rozpočet v 2027? autokorelace odchylek,
      backtest řezu VIII/2026 → IX–X). Volitelně zvaž v proměnné po měsících
      (např. PPC režim jen v určitých měsících 2027 – nastavitelný řádek vah).
   d) Dopočet XI–XII/2026 (krok 4) a pásmo 2027 navaž na stejné v, aby byl výstup konzistentní.
6) Forecast 2027 oběma vybranými modely: měsíčně, roční hodnota vážená objednávkami,
   YoY vs. 2026E, pásmo dolní/střed/horní (pásmo z backtest chyb nebo scénářů mixu).
7) Implikace pro cíl tržeb CZ (tabulka výše): pro každý měsíc 2027 a celý rok spočti
   potřebný růst objednávek = (1 + cíl tržeb) / (1 + růst AOV) − 1, pro oba modely
   a pro doporučené v i krajní varianty v = 0 a v = 1.
   Označ měsíce, kde je cíl (např. IV–V +10 %, VII–VIII +8 %) bez růstu objednávek
   nad historický rámec nereálný.

VÝSTUP
A) V chatu (max. 1 obrazovka):
   - Tabulka backtestu „jako v březnu 2026“ pro obě báze: model | MAPE | bias | ex ante?
   - Dva vybrané modely (1× GA/BI, 1× ERP) a proč.
   - Datum zlomu PPC a srovnání před/po (AOV, mix, PNO) – 1 krátká tabulka.
   - Tabulka forecast 2027: měsíce I–XII + rok, pro oba modely, YoY vs. 2026E,
     pro doporučené v; plus roční AOV pro v = 0 / 0,25 / 0,5 / 0,75 / 1.
   - Tabulka implikací: cíl tržeb CZ | růst AOV | potřebný růst objednávek, po měsících + rok.
   - Doporučená plánová hodnota AOV 2027 (BI i ERP báze) a pásmo.
   - 3–5 bodů: hlavní předpoklady, rizika, co data nevysvětlí (promo, produktový mix, služby).
B) Excel „AOV_2027_CZ_final.xlsx“ – listy: Návod, Souhrn, Data_BI, Data_ERP, BI_vs_ERP,
   Data_GA_denní, Zlom_PPC, Backtest, Model_GA (vybraný), Model_ERP (vybraný),
   Váha_VIII-X, Forecast_2027, Cíl_2027.
   Konvence: modrá = vstupní data, černá = vzorce, zelená = odkaz na jiný list,
   žlutá = měnitelné parametry (α, γ, w, v, váhy, k, cíle růstu) a klíčové výsledky. Výstupy
   Pythonu, které nejdou vzorcem (SARIMA), vlož jako modré hodnoty. Po uzavření měsíce stačí
   přepsat vstupy a vše se přepočte.

Nepiš mezikroky ani průběžné komentáře – dodej jen finální výsledek podle bodů A a B.
```

---

## Referenční výsledky z původní konverzace (pro kontrolu nového běhu)

| Ukazatel | Hodnota |
|---|---|
| Skutečnost AOV IX / X 2026 (BI) | 1 038 / 1 018 Kč |
| Skutečnost AOV IX / X 2026 (ERP) | 1 023 / 1 007 Kč |
| Vítěz backtestu GA/BI (řez 3/2026) | B3 mix posledních 4 M – MAPE 3,9 %, bias −2,6 % |
| Vítěz backtestu ERP (řez 3/2026) | TS1 ETS(A,N,A) α=γ=0,1 – MAPE 4,0 %, bias −0,9 % |
| AOV 2026E | BI 1 073 Kč (+1,4 %), ERP ≈ 1 062 Kč |
| XI / XII 2026 | BI 1 042 / 1 176 Kč (w = 0,5); ERP ≈ 1 046 / 1 154 Kč |
| AOV 2027 BI (Modely A/B) | 1 086 Kč, pásmo 1 078–1 107 Kč |
| AOV 2027 ERP (ensemble TS1+TS3) | 1 061 Kč, pásmo 1 013–1 079 Kč |
| Koeficient k = AOV BI / AOV ERP | 2025 ≈ 1,004, 2026 ≈ 1,011 (měsíčně 0,98–1,03) |

Hlavní poznatky: modely s trendem mají záporný bias (−3 až −7 %); měsíční AOV má šum ±3–6 %,
roční hodnota je plánovatelná s přesností ±1,5–2 %; zlomy v létě a na podzim 2026 nejsou
z časové řady vysvětlitelné (vnitrokanálový pokles košíku při vyšších mediálních výdajích).
